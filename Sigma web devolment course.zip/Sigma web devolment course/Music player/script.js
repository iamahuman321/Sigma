document.addEventListener('DOMContentLoaded', function () {
    // Function to handle adding new music files
    function handleFiles(files) {
        const playlist = document.getElementById('playlist');

        // Loop through each selected file
        for (const file of files) {
            const audio = document.createElement('audio');
            audio.src = URL.createObjectURL(file);
            audio.controls = true;

            const li = document.createElement('li');
            li.appendChild(audio);
            playlist.appendChild(li);
        }
    }

    // Get the file input element
    const fileInput = document.getElementById('musicFile');

    // Listen for changes to the file input
    fileInput.addEventListener('change', function () {
        handleFiles(this.files);
    });
});
