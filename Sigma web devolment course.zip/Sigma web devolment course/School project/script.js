var typed = new Typed('#element', {
    strings: ['Discover the wonders of nature', 'Explore diverse biomes', 'Protect our planet'],
    typeSpeed: 60,
});