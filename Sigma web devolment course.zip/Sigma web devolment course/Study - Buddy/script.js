  // JavaScript to toggle Google Docs system
  document.addEventListener('DOMContentLoaded', function () {
    const googleDocsIcon = document.getElementById('googleDocsIcon');
    const googleDocs = document.getElementById('googleDocs');

    googleDocsIcon.addEventListener('click', function () {
        googleDocs.classList.toggle('show');
    });

    const gmailIcon = document.getElementById('gmailIcon');
    const gmail = document.getElementById('gmail');

    gmailIcon.addEventListener('click', function () {
        gmail.classList.toggle('show');
    });
});

document.addEventListener('DOMContentLoaded', function () {
loadBookmarks();
loadNotes();
});

let timerInterval;
let timerRunning = false;
let seconds = 0;
let minutes = 0;
let hours = 0;
let alarmTime = 5 * 60; // 5 minutes (in seconds)
let alarmPlayed = false;

function startTimer() {
if (!timerRunning) {
timerInterval = setInterval(updateTimer, 1000);
timerRunning = true;
}
}

function stopTimer() {
clearInterval(timerInterval);
timerRunning = false;
}

function updateTimer() {
seconds++;
if (seconds === 60) {
seconds = 0;
minutes++;
if (minutes === 60) {
    minutes = 0;
    hours++;
}
}
const formattedTime = formatTime(hours) + ':' + formatTime(minutes) + ':' + formatTime(seconds);
document.getElementById('timer').textContent = formattedTime;

// Check if it's time for the alarm
if (seconds + (minutes * 60) + (hours * 3600) === alarmTime && !alarmPlayed) {
playAlarm();
}
}

function playAlarm() {
const alarmSound = document.getElementById('alarm-sound');
alarmSound.play();
alarmPlayed = true;
}

function formatTime(time) {
return time < 10 ? '0' + time : time;
}

function addBookmark() {
const nameInput = document.getElementById('bookmark-name');
const urlInput = document.getElementById('bookmark-url');
const categoryInput = document.getElementById('bookmark-category');

const name = nameInput.value.trim();
const url = urlInput.value.trim();
const category = categoryInput.value.trim();

if (name !== '' && url !== '' && category !== '') {
const bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];

bookmarks.push({ name, url, category });
localStorage.setItem('bookmarks', JSON.stringify(bookmarks));

loadBookmarks();
nameInput.value = '';
urlInput.value = '';
categoryInput.value = '';
} else {
alert('Please enter all details for the bookmark.');
}
}

function deleteBookmark(index) {
const confirmation = confirm('Are you sure you want to delete this bookmark?');
if (confirmation) {
const bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];
bookmarks.splice(index, 1);
localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
loadBookmarks();
}
}

function editBookmark(index) {
const bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];
const { name, url, category } = bookmarks[index];

const newName = prompt('Enter new name:', name);
const newUrl = prompt('Enter new URL:', url);
const newCategory = prompt('Enter new category:', category);

if (newName !== null && newUrl !== null && newCategory !== null) {
bookmarks[index] = { name: newName, url: newUrl, category: newCategory };
localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
loadBookmarks();
}
}

function toggleDarkMode() {
const body = document.body;
body.classList.toggle('dark-mode');
}

function loadBookmarks() {
const bookmarkList = document.getElementById('bookmark-list');
bookmarkList.innerHTML = '';

const bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];

bookmarks.forEach(({ name, url, category }, index) => {
const li = document.createElement('li');
li.className = 'bookmark-item';

// Create a clickable box for the entire bookmark
const clickableBox = document.createElement('div');
clickableBox.style.display = 'block'; // Make the box a block element to cover the entire width
clickableBox.style.cursor = 'pointer'; // Set cursor to pointer for better user experience

const nameElement = document.createElement('div');
nameElement.textContent = `${name} (${category})`; // Display name and category

// Append the name element to the clickable box
clickableBox.appendChild(nameElement);

// Add click event listener to the clickable box
clickableBox.addEventListener('click', function () {
    window.open(url, '_blank');
});

li.appendChild(clickableBox);

const iconsDiv = document.createElement('div');
iconsDiv.className = 'bookmark-icons';

const editIcon = document.createElement('i');
editIcon.className = 'fas fa-pencil-alt';
editIcon.title = 'Edit Bookmark';

const deleteIcon = document.createElement('i');
deleteIcon.className = 'fas fa-trash';
deleteIcon.title = 'Delete Bookmark';

editIcon.addEventListener('click', function () {
    editBookmark(index);
});

deleteIcon.addEventListener('click', function () {
    deleteBookmark(index);
});

iconsDiv.appendChild(editIcon);
iconsDiv.appendChild(deleteIcon);

li.appendChild(iconsDiv);
bookmarkList.appendChild(li);
});
}

function addNote() {
const noteContentInput = document.getElementById('note-content');
const noteContent = noteContentInput.value.trim();

if (noteContent !== '') {
const notes = JSON.parse(localStorage.getItem('notes')) || [];

const timestamp = new Date().toLocaleString();
notes.push({ content: noteContent, timestamp });
localStorage.setItem('notes', JSON.stringify(notes));

loadNotes();
noteContentInput.value = '';
} else {
alert('Please enter some content for the note.');
}
}

function deleteNote(index) {
const confirmation = confirm('Are you sure you want to delete this note?');
if (confirmation) {
const notes = JSON.parse(localStorage.getItem('notes')) || [];
notes.splice(index, 1);
localStorage.setItem('notes', JSON.stringify(notes));
loadNotes();
}
}

function loadNotes() {
const noteList = document.getElementById('note-list');
noteList.innerHTML = '';

const notes = JSON.parse(localStorage.getItem('notes')) || [];

notes.forEach(({ content, timestamp }, index) => {
const li = document.createElement('li');
li.className = 'note-item';

const contentElement = document.createElement('div');
contentElement.innerHTML = `<strong>${timestamp}</strong><br>${content}`;

const deleteButton = document.createElement('button');
deleteButton.textContent = 'Delete Note';
deleteButton.addEventListener('click', function () {
    deleteNote(index);
});

li.appendChild(contentElement);
li.appendChild(deleteButton);
noteList.appendChild(li);
});
}

function setAlarm() {
const alarmTime = document.getElementById('alarm-time').value;
if (alarmTime !== '') {
alert('Alarm is set for ' + alarmTime);
} else {
alert('Please select a valid time for the alarm.');
}
}

function checkAlarm(currentTime) {
const alarmTime = document.getElementById('alarm-time').value;
if (alarmTime === currentTime) {
alert('Alarm!');
}
}

document.addEventListener('DOMContentLoaded', function () {
loadBookmarks();
loadNotes();
initCalendar(); // Initialize the calendar when the DOM content is loaded
});

function initCalendar() {
var calendarEl = document.getElementById('calendar');

var calendar = new FullCalendar.Calendar(calendarEl, {
initialView: 'dayGridMonth', // Set the initial view of the calendar
headerToolbar: {
    left: 'prev,next today',
    center: 'title',
    right: 'dayGridMonth,timeGridWeek,timeGridDay'
},
events: [
    // Define your events here
    {
        title: 'Study Session',
        start: '2024-02-06T10:00:00',
        end: '2024-02-06T12:00:00'
    },
    {
        title: 'Group Meeting',
        start: '2024-02-10T14:00:00',
        end: '2024-02-10T16:00:00'
    }
    // Add more events as needed
]
});

calendar.render();
}
